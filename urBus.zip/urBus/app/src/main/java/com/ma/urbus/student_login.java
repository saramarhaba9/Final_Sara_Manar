package com.ma.urbus;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class student_login extends AppCompatActivity {
    private Button b1;
    private TextView tv1,tv2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_login);

        //button 1
        b1= (Button) findViewById(R.id.b1);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                open_student_home_activity();
            }
        });

        //TextView 1
        tv1= (TextView) findViewById(R.id.tv1);
        tv1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                open_password_reset_activity();
            }
        });
        //TextView 2
        tv2= (TextView) findViewById(R.id.tv2);
        tv2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                open_student_signup_activity();
            }
        });
    }
    public void open_student_home_activity(){
        Intent intent=new Intent(this, student_home.class);
        startActivity(intent);
    }

    public void open_password_reset_activity(){
        Intent intent=new Intent(this,password_reset.class);
        startActivity(intent);
    }
    public void open_student_signup_activity(){
        Intent intent=new Intent(this,student_signup.class);
        startActivity(intent);
    }


}