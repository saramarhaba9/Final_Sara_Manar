package com.ma.urbus;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class driver_login extends AppCompatActivity {
    private TextView tv1,tv2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_driver_login);
        //TextView 1
        tv1= (TextView) findViewById(R.id.tv1);
        tv1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                open_password_reset_activity();
            }
        });
        //TextView 2
        tv2= (TextView) findViewById(R.id.tv2);
        tv2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                open_driver_signup_activity();
            }
        });
    }

    public void open_password_reset_activity(){
        Intent intent=new Intent(this,password_reset.class);
        startActivity(intent);
    }

    public void open_driver_signup_activity(){
        Intent intent=new Intent(this,driver_signup.class);
        startActivity(intent);
    }

}